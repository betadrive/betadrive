package dev.matthy.betadrive.hud;

import java.util.Arrays;
import java.util.function.BiFunction;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_310;


public class HUDText {
    private final String statLabel;
    private final String statValue;
    public HUDText(String label, BiFunction<class_1657, class_1937,String> value) {
        statLabel = label;
        statValue = value.apply(class_310.method_1551().field_1724, class_310.method_1551().field_1687);
    }
    @Override
    public String toString() {
        return statLabel + "=" + statValue;
    }
    public static String build(HUDText... args) {
        return "["+String.join("  ", Arrays.stream(args).map(HUDText::toString).toList())+"]";
    }
}
