package dev.matthy.betadrive.hud;

import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;

public class HUDStat {
    class_327 renderer = class_310.method_1551().field_1772;
    public void printText(String text, int x, int y,int color, class_332 ctx) { // draw `color`-colored string `text` at (`x`,`y`) using context `ctx`
        class_5250 t = class_2561.method_43470(text);
        t.method_10862(class_2583.field_24360.method_27704(new class_11719.class_11721(class_2960.method_60655("betadrive", "ascii")))); // use our font
        ctx.method_51439(renderer,t,x,y,color,false);
    }
}