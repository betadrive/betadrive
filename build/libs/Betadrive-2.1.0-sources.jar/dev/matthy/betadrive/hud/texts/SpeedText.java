package dev.matthy.betadrive.hud.texts;

import dev.matthy.betadrive.hud.HUDText;
import net.minecraft.class_243;

public class SpeedText extends HUDText {
    public SpeedText() {
        super("MPS", (player, world) -> { // this function sucks! really bad! Doesn't account for elytra/creative flight/minecart/boat/etc.
            class_243 origin = new class_243(0,0,0);
            if((int) (player.method_18798().method_1022(origin)*1000) == 78) return "0"; // origin is a Vec3d = (0,0,0), checks if you're not moving
            int speed = Math.round(1000 * player.method_6029()); // only shows if running or not, but even if you're not moving it shows as 100
            if(speed == 100) return "4.317"; // walking
            if(speed == 130) return "5.612"; // running
            return "0"; // probably shouldn't happen!
        });
    }
}
