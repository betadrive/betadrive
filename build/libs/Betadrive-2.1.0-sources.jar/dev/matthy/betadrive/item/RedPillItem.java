package dev.matthy.betadrive.item;

import dev.matthy.betadrive.Betadrive;
import dev.matthy.betadrive.client.BetadriveClient;
import dev.matthy.betadrive.hud.MeterHUD;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;

public class RedPillItem extends class_1792 { // betadrive:red_pill
    public RedPillItem(class_1793 settings) {
        super(settings);
    }
    @Environment(EnvType.CLIENT)
    @Override
    public class_1269 method_7836(class_1937 world, class_1657 playerEntity, class_1268 hand) {
        try {
            if(!Betadrive.isAndroid) {
                BetadriveClient.mainHud = new MeterHUD(true, world);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        playerEntity.method_5998(hand).method_7934(1);
        return class_1269.field_21466;
    }
}