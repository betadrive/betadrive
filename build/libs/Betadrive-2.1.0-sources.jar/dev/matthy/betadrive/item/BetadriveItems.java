package dev.matthy.betadrive.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9886;
import net.minecraft.item.*;
import java.util.ArrayList;
import java.util.function.Function;
/*
public static final RegistryKey<ItemGroup> CUSTOM_ITEM_GROUP_KEY = RegistryKey.of(Registries.ITEM_GROUP.getKey(), Identifier.of(FabricDocsReference.MOD_ID, "item_group"));
public static final ItemGroup CUSTOM_ITEM_GROUP = FabricItemGroup.builder()
		.icon(() -> new ItemStack(ModItems.GUIDITE_SWORD))
		.displayName(Text.translatable("itemGroup.fabric_docs_reference"))
		.build();

 */
public class BetadriveItems {
    public static ArrayList<class_1792> groupAddable = new ArrayList<class_1792>();
    public static class_1792 CIRCUIT = register("circuit", class_1792::new, new class_1792.class_1793()); // material, betadrive:circuit
    public static class_1792 ADVANCED_CIRCUIT;
    public static class_1792 BATTERY = register("battery", BatteryItem::new, new class_1792.class_1793());
    public static class_1792 RED_PILL = register("red_pill", RedPillItem::new, new class_1792.class_1793()); // used to become an android, betadrive:red_pill
    public static class_1792 BLUE_PILL = register("blue_pill", BluePillItem::new, new class_1792.class_1793()); // used to not become an android, betadrive:blue_pill
    public static class_1792 ROBOFIST = register("robofist", properties -> new RobofistItem(class_9886.field_52590, 20, 4.0F,properties), new class_1792.class_1793()); // weapon, betadrive:robofist
    public static final class_5321<class_1761> BETADRIVE_GROUP_KEY = class_5321.method_29179(class_7923.field_44687.method_46765(), class_2960.method_60655("betadrive", "item_group"));
    public static final class_1761 BETADRIVE_ITEM_GROUP = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(CIRCUIT))
            .method_47321(class_2561.method_43471("itemGroup.betadrive"))
            .method_47324();
    public static class_1792 register(String path, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) { // register items
        final class_5321<class_1792> registryKey = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655("betadrive", path));
        class_1792 item = class_1802.method_51348(registryKey, factory, settings);
        groupAddable.add(item);
        return item;
    }
    public static class_1792 register(String path, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings, boolean includeInGroup) { // register items
        final class_5321<class_1792> registryKey = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655("betadrive", path));
        class_1792 item = class_1802.method_51348(registryKey, factory, settings);
        if(includeInGroup) groupAddable.add(item);
        return item;
    }
    public static void init() {
        class_2378.method_39197(class_7923.field_44687, BETADRIVE_GROUP_KEY, BETADRIVE_ITEM_GROUP);
        ItemGroupEvents.modifyEntriesEvent(BETADRIVE_GROUP_KEY).register(itemGroup -> {
            for (class_1792 item : groupAddable)
                itemGroup.method_45421(item); // add all the items put in groupAddable (via register override, includeInGroup=true, or not specified)
        });
    }
}