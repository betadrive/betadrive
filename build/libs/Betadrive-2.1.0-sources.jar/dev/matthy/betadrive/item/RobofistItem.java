package dev.matthy.betadrive.item;

import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_9886;

public class RobofistItem extends class_1792 { // betadrive:robofist
    private Random RANDOM = new Random();
    public RobofistItem(class_9886 toolMaterial, int attackDamage, float attackSpeed, net.minecraft.class_1792.class_1793 settings) {
        super(settings.method_66333(toolMaterial, attackDamage, attackSpeed));
    }

    @Override
    public class_1269 method_7847(class_1799 stack, class_1657 user, class_1309 entity, class_1268 hand) { // on right click,
        entity.method_6005(5, RANDOM.nextFloat()*100, RANDOM.nextFloat()*100); // random KB

        return super.method_7847(stack, user, entity, hand);
    }
}