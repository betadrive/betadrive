package dev.matthy.betadrive.item;

import dev.matthy.betadrive.BetadriveConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;

public class BatteryItem extends class_1792 { // betadrive:battery

    public BatteryItem(class_1793 settings) {
        super(settings);
    }
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        BetadriveConfig.fillBattery(user.method_5667(),world);
        user.method_5998(hand).method_7934(1);
        return class_1269.field_21466;
    }
}