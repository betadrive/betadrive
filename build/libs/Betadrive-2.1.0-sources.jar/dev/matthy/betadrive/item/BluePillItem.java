package dev.matthy.betadrive.item;

import dev.matthy.betadrive.BetadriveConfig;
import dev.matthy.betadrive.client.BetadriveClient;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class BluePillItem extends class_1792 { // betadrive:blue_pill
    public BluePillItem(class_1793 settings) {
        super(settings);
    }
    @Override
    public class_1269 method_7836(class_1937 world, class_1657 playerEntity, class_1268 hand) {
        BetadriveConfig.unBecomeAndroid();
        try{
            BetadriveClient.mainHud.clear();
            playerEntity.method_5998(hand).method_7934(1);
        } catch(Exception e) {
            assert class_310.method_1551().field_1724 != null;
            class_310.method_1551().field_1724.method_7353(class_2561.method_30163("You are not an android yet."), true); }
        return class_1269.field_21466;
    }
}