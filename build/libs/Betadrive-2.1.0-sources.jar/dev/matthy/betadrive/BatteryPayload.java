package dev.matthy.betadrive;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record BatteryPayload(float battery) implements class_8710 {
    public static final class_9154<BatteryPayload> ID = new class_9154<>(class_2960.method_60655("betadrive", "battery"));
    public static final class_9139<class_9129, BatteryPayload> CODEC = class_9139.method_56434(
            class_9135.field_48552, BatteryPayload::battery,
            BatteryPayload::new);
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return new class_9154<>(ID.comp_2242());
    }
}