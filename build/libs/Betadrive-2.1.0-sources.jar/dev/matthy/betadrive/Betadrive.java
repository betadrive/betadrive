package dev.matthy.betadrive;

import dev.matthy.betadrive.item.BetadriveItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1269;

public class Betadrive implements ModInitializer {
    public static float battery = 100;
    public static boolean isAndroid = false;
    @Override
    public void onInitialize() {
        BetadriveItems.init(); // add items

        PayloadTypeRegistry.playC2S().register(BatteryPayload.ID, BatteryPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(IsAndroidPayload.ID, IsAndroidPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(BatteryPayload.ID, (payload, context) -> battery = payload.battery());
        AttackEntityCallback.EVENT.register((player, w, h, e, hr) -> {
            float result = (float) Math.max(0d, battery - 0.01d);
            battery = result;
            if (result >= 0) return class_1269.field_52423;
            player.method_7344().method_7580(Math.max(player.method_7344().method_7586() - 1, 0));
            return class_1269.field_52423;
        });

        PlayerBlockBreakEvents.AFTER.register((w, player, bp, bs, be) -> {
            float result = (float) Math.max(0d, battery - 0.01d);
            battery = result;
            if (result >= 0) return;
            player.method_7344().method_7580(Math.max(player.method_7344().method_7586() - 1, 0));
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((player, d, b) -> battery = (float) Math.max(30d, battery));

//        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(literal("betadrive")
//                        .requires(source -> source.hasPermissionLevel(2))
//                        .then(literal("android")
//                                .then(literal("add").then(CommandManager.argument("username", StringArgumentType.greedyString()).executes(context -> {
//                                    final String username = StringArgumentType.getString(context, "username");
//                                    Betadrive.cfg.becomeAndroid(username);
//                                    context.getSource().sendFeedback(() -> Text.literal("Transformed %s into an android".formatted(username)), false);
//                                    return 1;
//                                }))).then(literal("remove").then(CommandManager.argument("username",StringArgumentType.greedyString())).executes(context -> {
//                                    final String username = StringArgumentType.getString(context, "username");
//                                    Betadrive.cfg.unBecomeAndroid(username);
//                                    context.getSource().sendFeedback(() -> Text.literal("Transformed %s into an human".formatted(username)), false);
//                                    return 1;
//                                })).executes(context -> {
//                                    context.getSource().sendFeedback(() -> Text.literal("o/"), false);
//                                    return 1;
//                                }))));
    }
}
