package dev.matthy.betadrive.mixin;

import dev.matthy.betadrive.client.BetadriveClient;
import dev.matthy.betadrive.hud.MeterHUD;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_329.class)
@Environment(EnvType.CLIENT)
public abstract class InGameHudMixin {

    @Unique
    private boolean isHudRendering = false;
    /**
     * @author Kate Matthy
     * @reason Add android HUD
     */
    @Overwrite
    private void renderCrosshair(class_332 context, class_9779 tickCounter) {
        if(BetadriveClient.mainHud == null || BetadriveClient.mainHud.cleared || (isHudRendering && !BetadriveClient.mainHud.finishedConverting)) return; // are we not an android, or is the hud already running?
        assert class_310.method_1551().field_1687 != null;
        BetadriveClient.mainHud  = new MeterHUD(false, class_310.method_1551().field_1687);
        isHudRendering = true; // don't make *another* mainHud object for no reason
        BetadriveClient.mainHud.finishedConverting = false;
    }
}