package dev.matthy.betadrive.android;

import net.minecraft.class_1657;

public class AndroidPlayer {
    private class_1657 player;
    private boolean isAndroid;
    private String name;
    public boolean isHudDone;
    private float battery;
    public AndroidPlayer(class_1657 playerEntity) {
        this.player = playerEntity;
        this.isAndroid = true;
        this.isHudDone = false;
        this.name = player.method_5477().getString();
        this.battery = 100;
    }
    public boolean isAndroid() {
        return this.isAndroid;
    }
    public class_1657 getPlayer() {
        return this.player;
    }
    public String getName() {
        return player.method_5477().getString();
    }
}