package dev.matthy.betadrive;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record IsAndroidPayload(boolean isAndroid) implements class_8710 {
    public static final class_9154<IsAndroidPayload> ID = new class_9154<>(class_2960.method_60655("betadrive", "is_android"));
    public static final class_9139<class_9129, IsAndroidPayload> CODEC = class_9139.method_56434(
            class_9135.field_48547, IsAndroidPayload::isAndroid,
            IsAndroidPayload::new);
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return new class_9154<>(ID.comp_2242());
    }
}